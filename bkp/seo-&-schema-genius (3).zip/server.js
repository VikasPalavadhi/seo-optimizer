
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { GoogleGenAI } from "@google/genai";
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// 1. Security Headers
app.use(helmet());

// 2. CORS - Restrict this to your DigitalOcean domain in production
app.use(cors({
  origin: process.env.FRONTEND_URL || '*', 
  methods: ['POST'],
  allowedHeaders: ['Content-Type']
}));

app.use(express.json({ limit: '10mb' }));

// 3. Rate Limiting - Protect your wallet/quota
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // Limit each IP to 20 requests per window
  message: { error: 'Too many audits from this IP, please try again later.' }
});
app.use('/api/', limiter);

// 4. Gemini SDK Initialization (Server Side)
const getAiInstance = () => {
  if (!process.env.API_KEY) {
    throw new Error("SERVER_CONFIG_ERROR: API_KEY is missing on the server.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// 5. Proxy Endpoint
app.post('/api/generate', async (req, res) => {
  try {
    const { contents, config, systemInstruction } = req.body;

    if (!contents || !systemInstruction) {
      return res.status(400).json({ error: 'Invalid request payload' });
    }

    const ai = getAiInstance();
    
    // We strictly use the model name and parameters defined in the request 
    // but executed in our secure server context
    const response = await ai.models.generateContent({
      model: config.model || 'gemini-3-flash-preview',
      contents: contents,
      config: {
        ...config,
        systemInstruction: systemInstruction,
        responseMimeType: "application/json"
      }
    });

    // Send only the text back to the client
    res.json({ 
      text: response.text,
      groundingMetadata: response.candidates?.[0]?.groundingMetadata 
    });

  } catch (error) {
    console.error('Gemini Proxy Error:', error);
    const status = error.status || 500;
    res.status(status).json({ 
      error: error.message || 'Internal Server Error',
      code: status
    });
  }
});

app.listen(PORT, () => {
  console.log(`SECURE BACKEND RUNNING ON PORT ${PORT}`);
  console.log(`PROTECTING KEY: ${process.env.API_KEY ? 'ACTIVE' : 'MISSING'}`);
});
