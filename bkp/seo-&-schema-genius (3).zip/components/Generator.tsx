
import React, { useState, useEffect, useRef } from 'react';
import { BrandProfile, PageType, Generation } from '../types';
import { PAGE_TYPES } from '../constants';
import { generateContent } from '../services/geminiService';

interface GeneratorProps {
  profile: BrandProfile;
  onComplete: (gen: Generation) => void;
}

const Generator: React.FC<GeneratorProps> = ({ profile, onComplete }) => {
  const [url, setUrl] = useState('');
  const [pastedHtml, setPastedHtml] = useState('');
  const [uploadedFile, setUploadedFile] = useState<{ name: string; data: string; mimeType: string } | null>(null);
  const [pageType, setPageType] = useState<PageType | 'auto'>('auto');
  const [inputMethod, setInputMethod] = useState<'text' | 'file'>('text');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<{ message: string; type: 'limit' | 'error' | 'timeout' } | null>(null);
  const [loadingTime, setLoadingTime] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let interval: any;
    if (isLoading) {
      interval = setInterval(() => setLoadingTime(prev => prev + 1), 1000);
    } else {
      setLoadingTime(0);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 15 * 1024 * 1024) {
      setError({ message: 'File too large. Please upload a document under 15MB.', type: 'error' });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(',')[1];
      setUploadedFile({
        name: file.name,
        data: base64,
        mimeType: file.type || 'application/octet-stream'
      });
      setUrl('');
      setPastedHtml('');
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    if (inputMethod === 'text' && !url.trim() && !pastedHtml.trim()) {
      setError({ message: 'Provide source URL or HTML content to begin audit.', type: 'error' });
      return;
    }
    if (inputMethod === 'file' && !uploadedFile) {
      setError({ message: 'Please upload a document to begin audit.', type: 'error' });
      return;
    }

    setIsLoading(true);
    setError(null);

    const TIMEOUT_MS = 120000; 
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('TIMEOUT')), TIMEOUT_MS)
    );

    try {
      let input: any = inputMethod === 'text' ? (url.trim() || pastedHtml.trim()) : { data: uploadedFile?.data, mimeType: uploadedFile?.mimeType };
      const isUrlInput = inputMethod === 'text' && !!url.trim();

      const apiCall = generateContent(
        input, 
        profile, 
        pageType === 'auto' ? undefined : (pageType as PageType),
        isUrlInput
      );

      const result: any = await Promise.race([apiCall, timeoutPromise]);

      if (!result || !result.seoVariants || result.seoVariants.length === 0) {
        throw new Error("Audit failed. Check source accessibility.");
      }

      const generation: Generation = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        url: url.trim() || uploadedFile?.name || (pastedHtml ? 'Manual Context' : 'Manual Audit'),
        profileId: profile.id,
        pageType: result.pageType || PageType.GENERIC,
        extracted: result.extraction,
        seoVariants: result.seoVariants,
        schemaJsonld: result.schemaJsonld,
        schemaCommentary: result.schemaCommentary,
        validation: result.validation,
        groundingSources: result.groundingSources,
        aiRecommendation: result.aiRecommendation,
        strategicImpact: result.strategicImpact
      };

      onComplete(generation);
    } catch (err: any) {
      console.error("SEO Audit Error:", err);
      let msg = err.message || 'Audit failed.';
      let type: 'limit' | 'error' | 'timeout' = 'error';

      if (err.message === 'TIMEOUT') {
        msg = 'Connection timed out.';
        type = 'timeout';
      } else if (msg.includes('429')) {
        msg = 'Engine is busy. Try again soon.';
        type = 'limit';
      }

      setError({ message: msg, type });
    } finally {
      setIsLoading(false);
    }
  };

  const clearInputs = () => {
    setUrl('');
    setPastedHtml('');
    setUploadedFile(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-16 max-w-6xl mx-auto">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="space-y-3">
          <h2 className="text-6xl font-black text-slate-900 tracking-tighter">SEO Audit</h2>
          <p className="text-[#414042] font-medium text-xl leading-relaxed">
            Optimizing for <span style={{ color: profile.primaryColor }} className="font-bold underline decoration-2 underline-offset-8">{profile.name}</span>.
          </p>
        </div>
        {(url || pastedHtml || uploadedFile) && !isLoading && (
          <button onClick={clearInputs} className="text-[11px] font-black text-[#414042] hover:text-rose-500 uppercase tracking-[0.4em] px-8 py-4 bg-white border border-slate-200 rounded-full transition-all shadow-sm active:scale-95">
            Clear Configuration
          </button>
        )}
      </header>

      <div className="bg-white rounded-[4rem] shadow-[0_48px_96px_-24px_rgba(0,0,0,0.08)] border border-slate-100 p-12 md:p-20 overflow-hidden">
        <div className="flex flex-col gap-16">
          
          {/* Main Input Toggle Area */}
          <div className="space-y-10">
            {inputMethod === 'text' ? (
              <div className="space-y-12 animate-in fade-in slide-in-from-top-4 duration-500">
                <section className="space-y-6">
                  <label className="text-[11px] font-black text-[#414042] uppercase tracking-[0.5em] ml-2 block opacity-60">Target Destination URL</label>
                  <div className="relative group">
                    <input 
                      type="url"
                      value={url}
                      disabled={isLoading}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="https://www.example.com/product-page"
                      className="w-full pl-16 pr-10 py-8 bg-[#f5f5f7]/50 border-2 border-transparent rounded-[2.5rem] focus:bg-white focus:border-[var(--brand-primary)] outline-none transition-all shadow-inner font-bold text-slate-900 text-xl placeholder:text-slate-300"
                    />
                    <div className="absolute left-7 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-[var(--brand-primary)] transition-colors">
                      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" /></svg>
                    </div>
                  </div>
                </section>

                <section className="space-y-6">
                  <label className="text-[11px] font-black text-[#414042] uppercase tracking-[0.5em] ml-2 block opacity-60">Direct Content / HTML Payload</label>
                  <textarea 
                    value={pastedHtml}
                    disabled={isLoading}
                    onChange={(e) => setPastedHtml(e.target.value)}
                    placeholder="Paste your page source or marketing copy here for deep semantic indexing..."
                    className="w-full px-10 py-10 bg-[#f5f5f7]/50 border-2 border-transparent rounded-[3rem] focus:bg-white focus:border-[var(--brand-primary)] outline-none transition-all shadow-inner font-medium text-[#414042] text-lg min-h-[320px] resize-none leading-relaxed placeholder:text-slate-300"
                  />
                </section>
              </div>
            ) : (
              <section className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <label className="text-[11px] font-black text-[#414042] uppercase tracking-[0.5em] ml-2 block opacity-60">Enterprise Asset Audit</label>
                <div 
                  onClick={() => !isLoading && fileInputRef.current?.click()}
                  className={`relative border-2 border-dashed rounded-[4rem] p-24 transition-all flex flex-col items-center justify-center gap-8 cursor-pointer ${isLoading ? 'opacity-30 grayscale cursor-not-allowed bg-[#f5f5f7]' : uploadedFile ? 'bg-indigo-50/20 border-indigo-200' : 'bg-[#f5f5f7]/30 border-slate-200 hover:border-[var(--brand-primary)] hover:bg-white'}`}
                >
                  <input type="file" ref={fileInputRef} className="hidden" accept=".pdf,.html,.txt" onChange={handleFileUpload} />
                  {uploadedFile ? (
                    <>
                      <div className="p-8 rounded-[2.5rem] shadow-2xl text-white transform transition-transform scale-110" style={{ backgroundColor: 'var(--brand-primary)' }}>
                        <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                      </div>
                      <div className="text-center">
                        <p className="font-black text-slate-900 text-2xl tracking-tight">{uploadedFile.name}</p>
                        <p className="text-sm font-black text-[#414042] mt-2 uppercase tracking-[0.2em] opacity-50">Document verified for processing</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center text-slate-300 shadow-sm border border-slate-100">
                        <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                      </div>
                      <div className="text-center space-y-2">
                        <p className="text-xl font-bold text-[#414042]">Drag & Drop Growth Assets</p>
                        <p className="text-xs font-black text-[#414042] uppercase tracking-[0.4em] opacity-40">PDF • HTML • TXT (MAX 15MB)</p>
                      </div>
                    </>
                  )}
                </div>
              </section>
            )}

            <div className="flex justify-center">
               <button 
                onClick={() => setInputMethod(inputMethod === 'text' ? 'file' : 'text')}
                className="text-[11px] font-black text-[#414042] hover:text-indigo-600 transition-all uppercase tracking-[0.4em] px-10 py-4 rounded-full border border-slate-200 hover:border-indigo-100 bg-white shadow-sm flex items-center gap-3 active:scale-95"
               >
                 <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                 {inputMethod === 'text' ? 'Analyze a document or PDF instead?' : 'Switch to Text/URL input mode'}
               </button>
            </div>
          </div>

          <div className="space-y-12 pt-16 border-t border-slate-50">
            <section className="space-y-8">
              <label className="text-[11px] font-black text-[#414042] uppercase tracking-[0.5em] ml-2 block opacity-60">Target Search Intent</label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                {['auto', ...PAGE_TYPES].map(type => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setPageType(type as any)}
                    className={`py-5 px-6 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest transition-all border-2 flex items-center justify-center gap-4 ${pageType === type ? 'text-white shadow-xl scale-[1.02]' : 'bg-white border-slate-50 text-[#414042] hover:border-slate-200 opacity-60 hover:opacity-100'}`}
                    style={pageType === type ? { backgroundColor: 'var(--brand-primary)', borderColor: 'var(--brand-primary)', opacity: 1 } : {}}
                  >
                    {type.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </section>

            <div className="pt-8">
              <button 
                type="button"
                onClick={handleGenerate}
                disabled={isLoading}
                className={`w-full py-12 rounded-[2.5rem] font-black text-2xl transition-all transform active:scale-[0.98] flex flex-col items-center justify-center relative overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.2)] ${isLoading ? 'bg-slate-100 text-[#414042] cursor-not-allowed opacity-40' : 'text-white hover:brightness-110 active:brightness-95 hover:shadow-[0_48px_80px_-20px_rgba(0,0,0,0.3)]'}`}
                style={!isLoading ? { backgroundColor: 'var(--brand-primary)' } : {}}
              >
                {isLoading ? (
                  <div className="flex flex-col items-center gap-5">
                    <svg className="animate-spin h-10 w-10" style={{ color: 'var(--brand-primary)' }} fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <span className="uppercase tracking-[0.5em] text-[11px] font-black">Processing Engine</span>
                  </div>
                ) : (
                  <span className="uppercase tracking-[0.4em]">Get SEO Details Now</span>
                )}
                {isLoading && <div className="absolute bottom-0 left-0 h-2 w-full animate-progress" style={{ backgroundColor: 'var(--brand-accent)' }} />}
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-12 px-10 py-8 bg-rose-50 rounded-[2.5rem] border-2 border-rose-100 flex items-start gap-6 animate-in shake duration-500">
            <div className="p-3 bg-white rounded-2xl shadow-sm text-rose-500">
              <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
            </div>
            <p className="font-bold text-rose-900 text-lg leading-relaxed mt-2">{error.message}</p>
          </div>
        )}
      </div>

      <footer className="text-center pt-10 pb-20">
        <p className="text-[11px] font-black text-[#414042] uppercase tracking-[0.5em] opacity-30">Global Enterprise Optimization Framework v3.1</p>
      </footer>
    </div>
  );
};

export default Generator;
